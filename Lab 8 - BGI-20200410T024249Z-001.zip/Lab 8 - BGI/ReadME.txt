1. Copy graphics.h and winbgim.h to your codeblocks-MinGW-include folder
2. Copy libbgi.a to codeblocks-MinGW-lib folder
3. Open codeblocks
4. Go to settings-Compiler-Linker settings
5. add libbgi.a
6. Click on the other options space
7. Paste the content of "Linker Settings" file